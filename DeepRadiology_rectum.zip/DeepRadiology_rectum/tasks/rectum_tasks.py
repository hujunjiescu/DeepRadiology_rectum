CTV = {1: ["CTV"]}

OAR_all = {1: ["Bladder", "Bladder  N"], 
           2: ["Femoral Head L", "Femoral  Haed L", "Femoral  Head  L"],
           3: ["Femoral Head R", "Femoral  Head  R"],
           4: ["Small intestine", "Small Intestine", "Small intensine", "small intestine"]}